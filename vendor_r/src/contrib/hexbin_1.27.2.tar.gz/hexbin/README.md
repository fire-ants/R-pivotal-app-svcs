hexbin
======
[![Build Status](https://travis-ci.org/edzer/hexbin.png?branch=master)](https://travis-ci.org/edzer/hexbin) [![CRAN](http://www.r-pkg.org/badges/version/hexbin)](http://cran.rstudio.com/package=hexbin) [![Downloads](http://cranlogs.r-pkg.org/badges/hexbin?color=brightgreen)](http://www.r-pkg.org/pkg/hexbin)

An R Package with binning and plotting functions for hexagonal bins.
